import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class Manager{
	
	public static File scoreFile = new File("scores.csv");
	public static String name = new String("");
	public static int clickedFruitCount = 0;
	public static boolean gameIsOver = false;
	
	public static int TotalScore = 0;
	public static Pane gamePane = new Pane();
	static int TIMESTEP_ms = 40;
	static int timer_ms = 3000; //ticks every unit of TIMESTEP_ms. Starts at 3 seconds to start a trigger
	static int totalTime_ms;
	public static int waitTime_ms;
	public static int MAX_WAITTIME_ms = 2000;
	public static int MIN_WAITTIME_ms = 300;
	
	//Fruit variables
	public static ArrayList<Fruit> fruitList = new ArrayList<Fruit>();
	public static ArrayList<Fruit> toRemoveFromFruitList = new ArrayList<Fruit>();
	
	public static int numberAtOnce;
	public static int MAX_NUMBERATONCE = 4;
	public static int MIN_NUMBERATONCE = 1;
	
	//Bomb variables
	public static ArrayList<Bomb> bombList = new ArrayList<Bomb>();
	public static ArrayList<Bomb> toRemoveFromBombList = new ArrayList<Bomb>();
	public static int BOMB_PROBABILITY = 40; //percentage
	
	
	
	public Manager(){
		
	}
	
	static Fruit createNewFruit(){
		Fruit newFruit = new Fruit();
		newFruit.Vx += Manager.totalTime_ms/15;
		fruitList.add(newFruit);
		gamePane.getChildren().add(newFruit);
		return newFruit;
	}
	
	static Bomb createNewBomb(){
		Bomb newBomb = new Bomb();
		newBomb.Vx += Manager.totalTime_ms/15;
		bombList.add(newBomb);
		gamePane.getChildren().add(newBomb);
		return newBomb;
	}
	
	static void UpdateScore(int changeAmount){
		
		TotalScore += changeAmount;
		clickedFruitCount += 1;
		
	}

	public static void SaveGame() {
		Stage stage = new Stage();
		GridPane pane = new GridPane();
		
		Text SaveGameText = new Text("Please honor us with your identity so we can save your score:");
		TextField CollectName = new TextField();
		Button Savebutton = new Button("Save");
		Savebutton.setOnAction(e -> {
			Manager.name = CollectName.getText();
			NinjaRW.SaveToFile();
			stage.close();
			});
		
		pane.add(SaveGameText, 0, 0);
		pane.add(CollectName, 0, 1);
		pane.add(Savebutton, 1, 1);

		// Create a scene and place it in the stage
	    Scene scene = new Scene(pane, 400, 300);
	    stage.setTitle("Save Yo Game"); // Set the stage title
	    stage.setScene(scene); // Place the scene in the stage
	    
	    stage.setResizable(false);// Locks the stage size 
	    stage.show(); // Display the stage
	}
	

	public static void GameOver() {
		
		//GUI.isPaused = true;
		gameIsOver = true;
		
		Stage stage = new Stage();
		GridPane pane = new GridPane();
		
		Text saveText = new Text("Would you like to Save \n      your final score?");
		Button saveButton = new Button("Save");
		saveButton.setOnAction(e -> {
			SaveGame();
			
			});
		Text replayText = new Text("   Do you wish to Replay \n the best time of your life?");
		Button replayButton = new Button("Replay");
		replayButton.setOnAction(e -> futureUpdate());
		Text exitText = new Text(" Would you like  \n to Exit the fun?");
		Button exitGameButton = new Button("Exit");
		exitGameButton.setOnAction(e -> System.exit(0));
		
		pane.setHgap(20);
		pane.setAlignment(Pos.CENTER);
		pane.add(saveText, 1, 0);
		pane.setHalignment(saveText, HPos.CENTER);
		pane.add(saveButton, 1, 1);
		pane.setHalignment(saveButton, HPos.CENTER);
		pane.add(replayText, 0, 2);
		pane.setHalignment(replayText, HPos.CENTER);
		pane.add(exitText, 2, 2);
		pane.setHalignment(exitText, HPos.CENTER);
		pane.add(replayButton, 0, 3);
		pane.setHalignment(replayButton, HPos.CENTER);
		pane.add(exitGameButton, 2, 3);
		pane.setHalignment(exitGameButton, HPos.CENTER);
		
		// Create a scene and place it in the stage
	    Scene scene = new Scene(pane, 400, 200);
	    stage.setOnCloseRequest(e -> Platform.exit());
	    stage.setOnHiding(e -> Platform.exit());
	    stage.setTitle("Game Over Yo"); // Set the stage title
	    stage.setScene(scene); // Place the scene in the stage
	    stage.setResizable(false);// Locks the stage size 
	    stage.show(); // Display the stage
	    
	}	
	
	public static void futureUpdate() {
		Stage stage = new Stage();
		GridPane pane = new GridPane();
		
		Text futureUpdateText = new Text("Pardon the incompleteness. This is only \n a glimpse at future features and with your financial \n support, this and much more can be achieved.");
		
		pane.add(futureUpdateText, 0, 0);
		pane.setAlignment(Pos.CENTER);

		// Create a scene and place it in the stage
	    Scene scene = new Scene(pane, 400, 300);
	    stage.setTitle("Future Update"); // Set the stage title
	    stage.setScene(scene); // Place the scene in the stage
	    
	    stage.setResizable(false);// Locks the stage size 
	    stage.show(); // Display the stage
	}
}
