import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import java.util.Random;

public class Fruit extends Circle {
	
	int fruitScore;
	double radius;
	double x , y ;
	double dx = 10, dy = 1;
	double Vx = 2000, Vy;
	double dt = 0.005;
	double a = 10000000;
	double yi;
	
	
	
	public Fruit(){
		setRadius(Rand_Radius());
		setFill(Paint.valueOf(Rand_Color()));
		setPosition();
		setVy();
		setOnMouseClicked(e ->{
			if(!GUI.isPaused && !Manager.gameIsOver){
				Manager.UpdateScore(fruitScore);
				Remove();
			}
		});
	}
	
	private void setPosition() {
		
		Random rand = new Random();
		int buff = (int)Manager.gamePane.getHeight();
		int startingY = rand.nextInt(buff) ;		
		
		x = -radius;
		yi = startingY;
		y = yi;
		setCenterX(x); //Will always starts on left edge
	    setCenterY(y);
	}
	
	private void setVy(){
		Random rand = new Random();
		Vy = rand.nextInt(500) + 500; // range of 500-1199
	}
	
	void Remove(){
		Manager.gamePane.getChildren().remove(this);
		Manager.toRemoveFromFruitList.add(this);
	}
	
	int Rand_Radius(){
		
		
		Random rand = new Random(); // Creating random object called rand 
		
		int  n = rand.nextInt(3) + 1; // RNG will generate numbers from 1 to 3, max being 3 and 1 being minimum 
		
		if (n == 1) {
			n = 30;
			fruitScore = 6;
		}
		else if (n == 2){
			n = 60;
			fruitScore = 3;
		}
		else if (n == 3){
			n = 80;
			fruitScore = 1; 
		}
			
		radius = n;
		
		return n;			
	}
	
	String Rand_Color(){
		
		
		String randColor = new String();
		Random rand = new Random(); // Creating random object called rand 
		
		int  n = rand.nextInt(3) + 1; // RNG will generate numbers from 0 to 3, max being 3 and 0 being minimum 
		
		if (n == 1) 
			randColor = "Blue";
		else if (n == 2)
			randColor = "Green";
		else if (n == 3)
			randColor = "Orange";
			
		return randColor; 
	}
	
	void moveBall() {
	    // Check boundaries
		
		if (x < -radius || x > Manager.gamePane.getWidth() + radius) {
	      //dx *= -1; // Change ball move direction
	      Remove();
		}
		
	    if (y < -radius || y > Manager.gamePane.getHeight() + radius) {
	      //dy *= -1; // Change ball move direction
	      Remove();
	    }

	    // Adjust ball position
	    x += Vx*dt;
	   	y = yi - x*(Vy/Vx) + ((a*x*x)/(2*Vx*Vx*Math.pow((Vx*Vx + Vy*Vy), 0.5)));
	    this.setCenterX(x);
	    this.setCenterY(y);  
	  
	}
	
	void GameOvermoveBall() {
	    // Check boundaries
		
		if (x < -radius || x > Manager.gamePane.getWidth() + radius) {
	      //dx *= -1; // Change ball move direction
	      Remove();
		}
		
	    if (y < -radius || y > Manager.gamePane.getHeight() + radius) {
	      //dy *= -1; // Change ball move direction
	      Remove();
	    }

	    // Adjust ball position
	    y += dx/2;
	    this.setCenterY(y);  
	  
	}
}