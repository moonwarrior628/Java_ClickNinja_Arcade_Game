import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import javafx.application.Application;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public abstract class NinjaRW extends Application{

	static final String COMMA_DELIMITER = ",";

	public NinjaRW(){
		
	}
	
	public static void SaveToFile() {
		//https://stackoverflow.com/questions/1625234/how-to-append-text-to-an-existing-file-in-java
		FileWriter fw;
		try {
			fw = new FileWriter(Manager.scoreFile,true);
			//BufferedWriter writer give better performance
	    	BufferedWriter bw = new BufferedWriter(fw);
	    	bw.write(Manager.name + "," + Manager.TotalScore + "," + Manager.clickedFruitCount + "\n");
	    	//Closing BufferedWriter Stream
	    	bw.close();
		} catch (IOException e) {
			System.out.println("ERROR: A problem occured when saving the game!!");
			e.printStackTrace();
		}
    	
	}

	public static String[] getBestPlayerStats() {
		String[] bestPlayerStats = new String[3];
		double highestScore = -1;
		double buffScore;
		
		BufferedReader br = null;
        try
        {
            //Reading the csv file
            br = new BufferedReader(new FileReader(Manager.scoreFile));
            String line = "";

            //Reading line by line
            while ((line = br.readLine()) != null)
            {
            	System.out.println(line);
            	String[] row = line.split(COMMA_DELIMITER);
            	System.out.println(row[0]);

                if(row.length > 0 )
                {
                	try
                    {
                		buffScore = Double.parseDouble(row[1]);
                		Double.parseDouble(row[2]); //checks that the 3rd row is a number, if not, will throw an exception 
                		//System.out.println(row[0]);
                		if(buffScore > highestScore){
                			highestScore = Double.parseDouble(row[1]);
                			bestPlayerStats[0] = row[0];
                			bestPlayerStats[1] = row[1];
                			bestPlayerStats[2] = row[2];
                		}
                    }
                	catch(NumberFormatException ie)
                    {
                		System.out.println("Invalid player data");
                    }
                	catch(Exception ee)
                    {
                        ee.printStackTrace();
                    }
                }
            }
            if(highestScore < 0){
            	bestPlayerStats[0] = "You are the First Player";
            	bestPlayerStats[1] = "0";
            	bestPlayerStats[2] = "0";
            }
        }
        catch(FileNotFoundException ee)
        {
        	System.out.println("File not found");
        }
        catch(Exception ee)
        {
            ee.printStackTrace();
        }
        finally
        {
            try
            {
                br.close();
            }
            catch(IOException ie)
            {
                System.out.println("Error occured while closing the BufferedReader");
                ie.printStackTrace();
            }
        }
		return bestPlayerStats;
	}

}
