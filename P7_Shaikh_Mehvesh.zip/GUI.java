import java.util.Iterator;
import java.util.Random;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GUI extends Application {
	
	private Timeline animation;
	private BorderPane borderPane;
	public static volatile boolean isPaused=false;
	private MenuBar menuBar;	// MenuBar
	private Menu menuFile, menuScoreBoard, menuInfo;	// Menus
	private MenuItem miNewGame, miPauseGame,miSaveGame, miExitGame;							// Close MenuItem
	private MenuItem miStatistics;				// Shows/clears all shapes
	private MenuItem miHelp, miAbout;							// Displays info about the program
	

	
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage){
				
		Manager.waitTime_ms = 3000; //Starts at 3 seconds to start a trigger
		
		// Create an animation for moving the ball
	    animation = new Timeline(
	      new KeyFrame(Duration.millis(Manager.TIMESTEP_ms), e -> {
	    	  if(!isPaused){
		    	  //Move the Fruits
		    	  Iterator<Fruit> fruitSort = Manager.fruitList.iterator();
		    	  Fruit bufferFruit = null;
		    	  
		    	  while(fruitSort.hasNext()){
		    		  bufferFruit = fruitSort.next();
		    		  if(Manager.gameIsOver){
		    			  bufferFruit.GameOvermoveBall();
		    		  }
		    		  else{
		    			  bufferFruit.moveBall();
		    		  }
		    	  }
		    	  
		    	  if(!Manager.toRemoveFromFruitList.isEmpty()){
		    		  Manager.fruitList.removeAll(Manager.toRemoveFromFruitList);
		    		  Manager.toRemoveFromFruitList.clear();
		    	  }
		    	  
		    	  //Move the Bombs
		    	  Iterator<Bomb> bombSort = Manager.bombList.iterator();
		    	  Bomb bufferBomb = null;
		    	  
		    	  while(bombSort.hasNext()){
		    		  bufferBomb = bombSort.next();
		    		  if(Manager.gameIsOver){
		    			  bufferBomb.GameOvermoveBall();
		    		  }
		    		  else{
		    			  bufferBomb.moveBall();
		    		  }
		    	  }
		    	  
		    	  if(!Manager.toRemoveFromBombList.isEmpty()){
		    		  Manager.bombList.removeAll(Manager.toRemoveFromBombList);
		    		  Manager.toRemoveFromBombList.clear();
		    	  }
		    	  
		    	  //Enters this after a randomly decided duration	
		    	  if(Manager.timer_ms >= Manager.waitTime_ms){
		    		  
		    		  Manager.totalTime_ms += Manager.timer_ms; //increase total time
		    		  Manager.timer_ms = 0; //resets timer
		    		  Random rand = new Random(); // Creating random object called rand
		    		  int i;
						  
		    		  Manager.numberAtOnce = rand.nextInt(Manager.MAX_NUMBERATONCE - Manager.MIN_NUMBERATONCE + 1) + Manager.MIN_NUMBERATONCE; // RNG will generate numbers from 2 to 5, max being 5 and 2 being minimum 
		    		  Manager.waitTime_ms = (rand.nextInt((Manager.MAX_WAITTIME_ms - Manager.MIN_WAITTIME_ms + 1) + Manager.MIN_WAITTIME_ms));// RNG will generate numbers from 300 to 2000 milliseconds, max being 3000 and 300 being minimum. However, over time, the 2500 millisecond max will shorten by (TotalTime_ms/60) 
		    		  
		    		  //creates the number of fruit randomly generated a few lines up
		    		  for (i = 0; i < Manager.numberAtOnce; i++){	
		    			  Manager.createNewFruit();
		    		  }
		    		  
		    		  //"rolls the dice" to see if a bomb is created
		    		  if(rand.nextInt(100) < Manager.BOMB_PROBABILITY){
		    			  Manager.createNewBomb();
		    		  } 		  
		    	  }
		    	  else{
		    		  //If times hasn't finished, just increase total time
		    		  Manager.timer_ms += Manager.TIMESTEP_ms;
		    	  }
	    	  }
	      }));
	    animation.setCycleCount(Timeline.INDEFINITE);
	    animation.play(); // Start animation
		
	    // Create a scene and place it in the stage
	    
	    borderPane = new BorderPane();

	    miNewGame = new MenuItem("New Game");
	    miPauseGame = new MenuItem("Pause Game");
		miSaveGame = new MenuItem("Save Game");
		miExitGame = new MenuItem("Exit Game");
		miStatistics = new MenuItem("Statistics");
		miHelp = new MenuItem("Help");
		miAbout = new MenuItem("About");
		
		// Create Menus
		menuFile = new Menu("File");
		menuScoreBoard = new Menu("ScoreBoard");
		menuInfo = new Menu("Info");
		
		// Create MenuBar
		menuBar = new MenuBar();
		// Add menu items to respective menus
		menuFile.getItems().addAll(miNewGame, miPauseGame, miSaveGame, miExitGame);
		menuScoreBoard.getItems().add(miStatistics);
		menuInfo.getItems().addAll(miHelp,miAbout);
		// Add menus to menuBar
		menuBar.getMenus().addAll(menuFile, menuScoreBoard, menuInfo);
		

		//Menu Button Stuff
	    miNewGame.setOnAction(e -> Manager.futureUpdate());
		miSaveGame.setOnAction(e -> {
			isPaused = true;
			Manager.SaveGame();
		});
		miExitGame.setOnAction(e -> Platform.exit());
		
		miPauseGame.setOnAction(e -> {
			isPaused=!isPaused;
		});
		miStatistics.setOnAction(e -> GameStat());
		
		miHelp.setOnAction(e -> {
			Instructions();
		});
		//miHelp.setOnAction(e -> {isPaused=!isPaused;});
		miAbout.setOnAction(e -> {showAbout();});
		
		//Put everything together:
		Scene scene = new Scene(borderPane, 1000, 700);
		// Add the menubar and shapes to the borderpane
		
		borderPane.setCenter(Manager.gamePane);
		borderPane.setTop(menuBar);
		
		// Configure and display the stage
		primaryStage.setTitle("The Click Ninja");
		primaryStage.setOnCloseRequest(e -> Platform.exit());
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
			
	    Manager.gamePane.setFocusTraversable(true);
	    
	}

	public static void main(String[] args) {
	    launch(args);
	}
	
	private void GameStat(){

		
		Stage stage = new Stage();
		
		GridPane pane = new GridPane();
		
		String[] bestPlayerStats = NinjaRW.getBestPlayerStats();
		
		pane.add(new Text("Best Player"), 0, 0);
		pane.add(new Text(bestPlayerStats[0]), 1, 0);
		pane.add(new Text("Highest Score"), 0, 1);
		pane.add(new Text(bestPlayerStats[1]), 1, 1);
		pane.add(new Text("No. of Balls hit"), 0, 2);
		pane.add(new Text(bestPlayerStats[2]), 1, 2);
		pane.add(new Text("Your Stats"), 0, 4);
		pane.add(new Text(""), 1, 4);
		pane.add(new Text("Your Score"), 0, 5);
		pane.add(new Text(Manager.TotalScore + ""), 1, 5);
		pane.add(new Text("Your Clicked Fruit Count"), 0, 6);
		pane.add(new Text(Manager.clickedFruitCount + ""), 1, 6);
		pane.setGridLinesVisible(true);
		
		// Create a scene and place it in the stage
	    Scene scene = new Scene(pane, 400, 300);
	    stage.setTitle("Game Statistics"); // Set the stage title
	    stage.setScene(scene); // Place the scene in the stage
	    
	    stage.setResizable(false);// Locks the stage size 
	    stage.show(); // Display the stage
		
	}
	
	/** Shows information about the program in it's own window */
	private void showAbout(){

		final String aboutText = "This game was crafted by the bare hands of Mehvesh Shaikh to put up a show on this white blue screen. The crafter works at her shop at Embry Riddle Aeronautical CraftSity. "
				+ "Modification and redistribution of this craft is highly prohibited.  All rights and skills reserved.";

		Alert popup = new Alert(Alert.AlertType.INFORMATION, aboutText, ButtonType.OK);
		
		popup.setHeaderText("About This Program");
		popup.setTitle("About");
		popup.showAndWait();
		
	}

	private void Instructions(){
		
		final String aboutText = " In order to score in this game you have to click the circles and avoid the black circles because they are BOMBS. Each circle has a different size which determines different scores. "
				+ "Its easy2 Now go Play!!.";

		Alert popup = new Alert(Alert.AlertType.NONE, aboutText, ButtonType.OK);
		
		popup.setHeaderText("How to Play");
		popup.setTitle("Instructions");
		popup.showAndWait();
		
	}
		
	
}